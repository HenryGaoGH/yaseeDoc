//
//  ICAlgDef.h
//  ICDeviceManager
//
//  Created by Symons on 2019/10/17.
//  Copyright © 2019 Symons. All rights reserved.
//

#ifndef ICAlgDef_h
#define ICAlgDef_h

#define ENABLE_WLA01   0

#define ENABLE_WLA02   0

#define ENABLE_WLA03   0

#define ENABLE_WLA04   0

#define ENABLE_WLA05   0

#define ENABLE_WLA06   0

#define ENABLE_WLA07   1

#define ENABLE_WLA08   0

#define ENABLE_WLA09   0

#define ENABLE_WLA10   0

#define ENABLE_WLA11   0

#define ENABLE_WLA12   1

#define ENABLE_WLA13   0

#define ENABLE_WLA14   0

#define ENABLE_WLA15   0

#define ENABLE_WLA16   0

#define ENABLE_WLA17   0

#define ENABLE_WLA18   0

#define ENABLE_WLA19   0

#define ENABLE_WLA20   0

#define ENABLE_WLA22   0

#define ENABLE_WLA23   0

#define ENABLE_WLA24   0

#define ENABLE_WLA25   1

#define ENABLE_WLA26   0

#define ENABLE_WLA27   0

#define ENABLE_WLA28   0

#define ENABLE_WLA29   0

#define ENABLE_WLA30   0

#define ENABLE_WLA31   0

#define ENABLE_WLA32   0

#define ENABLE_WLA33   0

#define ENABLE_WLA34   1

#define ENABLE_WLA35   0

#define ENABLE_WLA36   1

#define ENABLE_WLA37   1

#define ENABLE_WLA38   0

#define ENABLE_WLA1001 0

#endif /* ICAlgDef_h */
