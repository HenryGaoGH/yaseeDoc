//
//  ICCallback_Inc.h
//  ICDeviceManager
//


#ifndef ICCallback_Inc_h
#define ICCallback_Inc_h

#import <ICDeviceManager/ICScanDeviceDelegate.h>

#endif /* ICCallback_Inc_h */
