# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# 暂时没有
-dontwarn com.alibaba.aliagentsdk.**
-dontwarn com.jieli.jl_bt_ota.**
-dontwarn com.jieli.jl_rcsp.**
-dontwarn no.nordicsemi.android.dfu.**
-keep class com.yasee.yasee.core.tools.Logs { public *; }
-dontwarn com.yasee.yasee.core.tools.Logs
-dontwarn com.yasee.yasee.core.tools.StringTool



-dontwarn cn.hutool.aop.proxy.CglibProxyFactory
-dontwarn cn.hutool.aop.proxy.JdkProxyFactory
-dontwarn cn.hutool.aop.proxy.SpringCglibProxyFactory
-dontwarn cn.hutool.extra.expression.engine.aviator.AviatorEngine
-dontwarn cn.hutool.extra.expression.engine.jexl.JexlEngine
-dontwarn cn.hutool.extra.expression.engine.jfireel.JfireELEngine
-dontwarn cn.hutool.extra.expression.engine.mvel.MvelEngine
-dontwarn cn.hutool.extra.expression.engine.qlexpress.QLExpressEngine
-dontwarn cn.hutool.extra.expression.engine.rhino.RhinoEngine
-dontwarn cn.hutool.extra.expression.engine.spel.SpELEngine
-dontwarn cn.hutool.extra.pinyin.engine.bopomofo4j.Bopomofo4jEngine
-dontwarn cn.hutool.extra.pinyin.engine.houbbpinyin.HoubbPinyinEngine
-dontwarn cn.hutool.extra.pinyin.engine.jpinyin.JPinyinEngine
-dontwarn cn.hutool.extra.pinyin.engine.pinyin4j.Pinyin4jEngine
-dontwarn cn.hutool.extra.pinyin.engine.tinypinyin.TinyPinyinEngine
-dontwarn cn.hutool.extra.template.engine.beetl.BeetlEngine
-dontwarn cn.hutool.extra.template.engine.enjoy.EnjoyEngine
-dontwarn cn.hutool.extra.template.engine.freemarker.FreemarkerEngine
-dontwarn cn.hutool.extra.template.engine.jetbrick.JetbrickEngine
-dontwarn cn.hutool.extra.template.engine.rythm.RythmEngine
-dontwarn cn.hutool.extra.template.engine.thymeleaf.ThymeleafEngine
-dontwarn cn.hutool.extra.template.engine.velocity.VelocityEngine
-dontwarn cn.hutool.extra.template.engine.wit.WitEngine
-dontwarn cn.hutool.extra.tokenizer.engine.analysis.SmartcnEngine
-dontwarn cn.hutool.extra.tokenizer.engine.ansj.AnsjEngine
-dontwarn cn.hutool.extra.tokenizer.engine.hanlp.HanLPEngine
-dontwarn cn.hutool.extra.tokenizer.engine.ikanalyzer.IKAnalyzerEngine
-dontwarn cn.hutool.extra.tokenizer.engine.jcseg.JcsegEngine
-dontwarn cn.hutool.extra.tokenizer.engine.jieba.JiebaEngine
-dontwarn cn.hutool.extra.tokenizer.engine.mmseg.MmsegEngine
-dontwarn cn.hutool.extra.tokenizer.engine.mynlp.MynlpEngine
-dontwarn cn.hutool.extra.tokenizer.engine.word.WordEngine
-dontwarn cn.hutool.log.dialect.commons.ApacheCommonsLogFactory
-dontwarn cn.hutool.log.dialect.jboss.JbossLogFactory
-dontwarn cn.hutool.log.dialect.log4j.Log4jLogFactory
-dontwarn cn.hutool.log.dialect.log4j2.Log4j2LogFactory
-dontwarn cn.hutool.log.dialect.logtube.LogTubeLogFactory
-dontwarn cn.hutool.log.dialect.slf4j.Slf4jLogFactory
-dontwarn cn.hutool.log.dialect.tinylog.TinyLog2Factory
-dontwarn cn.hutool.log.dialect.tinylog.TinyLogFactory