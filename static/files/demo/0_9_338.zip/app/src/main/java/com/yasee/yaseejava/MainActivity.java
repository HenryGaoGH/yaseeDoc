package com.yasee.yaseejava;

import static com.yasee.yaseejava.tools.PermissionHelper2.REQUEST_CODE_ALL;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.gson.reflect.TypeToken;
import com.yasee.yasee.Devices;
import com.yasee.yasee.Notify;
import com.yasee.yasee.Yasee;
import com.yasee.yasee.core.abstracts.Device;
import com.yasee.yasee.core.configs.LogConfig;
import com.yasee.yasee.core.models.AdvertisementData;
import com.yasee.yasee.core.tools.AsyncManager;
import com.yasee.yasee.core.tools.StringTool;
import com.yasee.yasee.protocols.ble.BleDevice;
import com.yasee.yasee.core.enums.DeviceProcess;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yasee.core.configs.BleConfig;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yaseejava.databinding.ActivityMainBinding;
import com.yasee.yaseejava.tools.PermissionHelper;
import com.yasee.yaseejava.tools.PermissionHelper2;
import com.yasee.yaseejava.tools.ShortcutUtil;
import com.yasee.yaseejava.tools.ToolLocalData;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    static List<BleDevice> binds = new ArrayList<>();
    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private NavController navController;
    private PermissionHelper permissionManager;

    private boolean isShow = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Yasee.getSingle().setContext(getApplicationContext());
        Yasee.getSingle().bleConfig = new BleConfig(5);
        Yasee.getSingle().logConfig = new LogConfig(true,true,true,true);



        permissionManager = new PermissionHelper(MainActivity.this);
        permissionManager.requestPermissions(new PermissionHelper.PermissionCallback() {
            @Override
            public void onPermissionGranted() {
                Toast.makeText(MainActivity.this, "所有权限已授予", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied(String[] pps) {
                Toast.makeText(MainActivity.this, "以下权限被拒绝: " + String.join(",",pps), Toast.LENGTH_SHORT).show();
            }
        });
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Yasee.getSingle().scan();
            }
        });

        binding.filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 创建PopupMenu
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, view);
                popupMenu.getMenu().add("tmd");
                popupMenu.getMenu().add("hlw");
                popupMenu.getMenu().add("wl");
                popupMenu.getMenu().add("yc");
                // 设置菜单项的点击监听器
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        Fragment navHostFragment = getSupportFragmentManager().getFragments().get(0);

                        if (navHostFragment instanceof NavHostFragment) {
                            ScanFragment currentFragment = (ScanFragment) navHostFragment.getChildFragmentManager().getPrimaryNavigationFragment();
                            if (currentFragment != null) {
                                Log.d("CurrentFragment", "当前 Fragment 是: " + currentFragment.getClass().getSimpleName());
                                currentFragment.filter(item.getTitle());
                            }
                        }
                        return false;
                    }
                });

                // 显示PopupMenu
                popupMenu.show();
            }
        });

        binding.localData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 设置 已绑定列表
                ToolLocalData.getInstance(getApplicationContext())
                        .putObject("device_list",binds);
            }
        });
        binding.localData.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Type type = new TypeToken<ArrayList<BleDevice>>() {}.getType();
                binds = ToolLocalData.getInstance(getApplicationContext())
                        .getObjectWithType("device_list",type);
                if (binds == null) return false;
                Devices.getSingle().initDevices(binds);
                return false;
            }
        });


        Notify.getSingle().listen(_state);
        // 远程绑定设备
        binding.linkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AdvertisementData adv = new AdvertisementData(new HashMap<>());
                String mac = binding.macInput.getText().toString();
//                adv.setkCBAdvDataLocalName("Y917-"+mac.substring(12));
//                String mac = "C40000000002";
                String _mac = String.join(":",StringTool.splitByLength(mac,2));
                adv.setkCBAdvDataLocalName("MIWD-"+mac.substring(8));

                BleDevice bd =  new BleDevice(_mac,"MIWD-"+mac.substring(8), adv);
                Devices.getSingle().addedBindDevice(bd);
                bd.connect();
            }
        });


        try {
            testSerial();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @SuppressLint("ResourceType")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent _binds = new Intent(MainActivity.this, SerialActivity.class);
            startActivity(_binds);
            return true;
        } else if (id == R.id.action_masschip) { // 白细胞
            Intent _mc = new Intent(MainActivity.this, Masschip.class);
            startActivity(_mc);
            return true;
        } else if (id == R.id.action_ecg) { // ECG图
            Intent _mz = new Intent(MainActivity.this, MzActivity.class);
            startActivity(_mz);
            return true;
        } else if (id == R.id.action_ocr) { // OCR 扫描
            Intent _mz = new Intent(MainActivity.this, Ocr.class);
            startActivity(_mz);
            return true;
        } else if (id == R.id.action_ky) { // 康云 扫描
            Intent _mz = new Intent(MainActivity.this, ActivityKy.class);
            startActivity(_mz);
            return true;
        }
        else if (id == R.id.action_link) { // 快捷方式

            AsyncManager.getInstance().postWithCallback(() -> {
                Intent intent = new Intent("miui.intent.action.APP_PERM_EDITOR");
                intent.putExtra("extra_pkgname", getPackageName());
                startActivity(intent);
            },()->{
                ShortcutUtil.createShortcut(this);
            });

        }
        else if (id == R.id.action_replace_icon) { // 替换图标
            String _a = "com.yasee.yaseejava.LauncherAltTF";
            String _b = "com.yasee.yaseejava.LauncherDefault";
            ShortcutUtil.switchLauncherIcon(
                this,
                isShow ? _a : _b,
                isShow ? _b : _a
            );
            isShow = !isShow;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    NotifyInterface _state = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceLink;
        }
        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleLink bleLink = (NotifyResp.BleLink) data.data;
            if (bleLink.process != DeviceProcess.linked) return;
            Bundle _bd = new Bundle();
            _bd.putString("mac",((BleDevice) ((NotifyResp.BleLink) data.data).device).getMac());
        }
    };


    /*
    * test serial
    * */
    void testSerial() throws IOException {

    }


    private void requestAllPermissions() {
        List<String> allPermissions = new ArrayList<>();
        allPermissions.addAll(PermissionHelper2.getBlePermissions());
        allPermissions.addAll(PermissionHelper2.getWifiPermissions());
        allPermissions.addAll(PermissionHelper2.getStoragePermissions());
        allPermissions.addAll(PermissionHelper2.getCameraPermissions());

        List<String> needRequest = new ArrayList<>();
        for (String p : allPermissions) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needRequest.add(p);
            }
        }

        if (!needRequest.isEmpty()) {
            PermissionHelper2.requestPermissions(this, needRequest, REQUEST_CODE_ALL);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                !PermissionHelper2.hasManageExternalStoragePermission()) {
            PermissionHelper2.requestManageExternalStoragePermission(this);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permissionManager.onRequestPermissionsResult(requestCode,permissions,grantResults);
//        if (requestCode == REQUEST_CODE_ALL) {
//            boolean allGranted = true;
//            for (int result : grantResults) {
//                if (result != PackageManager.PERMISSION_GRANTED) {
//                    allGranted = false;
//                    break;
//                }
//            }
//            if (allGranted) {
//                // 权限全部授予
//            } else {
//                // 有权限被拒绝
//            }
//        }
    }

}