package com.yasee.yaseejava.tools;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;

import com.yasee.yaseejava.Masschip;
import com.yasee.yaseejava.R;

public class ShortcutUtil {

    public static void createShortcut(Context context) {
        ShortcutManager shortcutManager = context.getSystemService(ShortcutManager.class);

        if (shortcutManager != null && shortcutManager.isRequestPinShortcutSupported()) {

            Intent intent = new Intent(context, Masschip.class);
            intent.setAction(Intent.ACTION_VIEW);

            ShortcutInfo shortcut = new ShortcutInfo.Builder(
                    context,
                    "shortcut_main"
            )
                    .setShortLabel("快捷入口")
                    .setLongLabel("打开核心功能")
                    .setIcon(Icon.createWithResource(
                            context,
                            R.mipmap.ic_launcher_round
                    ))
                    .setIntent(intent)
                    .build();

            shortcutManager.requestPinShortcut(shortcut, null);
        }
    }


    public static void switchLauncherIcon(
            Context context,
            String enableAlias,
            String disableAlias
    ) {
        PackageManager pm = context.getPackageManager();

        pm.setComponentEnabledSetting(
                new ComponentName(context, enableAlias),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
        );

        pm.setComponentEnabledSetting(
                new ComponentName(context, disableAlias),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
        );
    }


}