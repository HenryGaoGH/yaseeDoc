//
//  PlatformHlw.swift
//  yasee_ios_demo
//
//  Created by Henry Gao on 2024/8/22.
//

import Foundation
import yasee_ios
import HlwToYasiSDK


// MARK: 好络纬平台代码
class PlatformHlw : NSObject, Platform  {
    static let single: PlatformHlw = PlatformHlw()
    private override init() {
        super.init()
        _ = BleConnection.shared()
    }
    
    var type: yasee_ios.PlatformType = .protocol
    
    var service: [yasee_ios.BleService] {
        //在这里提供 建立蓝牙通许所需要的 服务、特征等 UUID 属性信息
        return []
    }
    
    // MARK: ======================= 签名、校验
    var used: Bool = false
    func sign(_ raw: [Int]) throws -> Data {
        // 这里提供 发送数据的 签名
        Data()
    }
    func check(_ raw: Data) throws -> Bool {
        //这里是 提供 外设过来数据的校验
        true
    }

    // MARK: ======================= 外设过来 数据解析过程
    func data(raw: Data) throws -> [String : String] {
        [:]
    }
    
    func mac(_ avdData: yasee_ios.AdvertisementData?) -> String? {
        // 这里解析设备MAC地址 后期可以扩展出更多信息(动态调整)
        nil
    }
    
    
}

extension PlatformHlw: BleConnectionDelegate {
    
}
