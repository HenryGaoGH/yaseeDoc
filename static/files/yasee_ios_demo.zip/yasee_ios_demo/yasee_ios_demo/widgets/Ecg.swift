//
//  Ecg.swift
//  yasee_ios_demo
//
//  Created by Henry Gao on 2024/9/13.
//

import SwiftUI
import yasee_ios


struct Ecg: View {
    
    // 模拟心电图数据
    @StateObject
    private var ecgNotify = EcgNotify()
    

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottomLeading) {
                // 1. 绘制网格
                drawGrid(size: geometry.size)
                
                // 心电线
                Path { path in
                    // 确保有数据
                    guard ecgNotify.ecgData.count > 1 else { return }
                    
                    // 设置心电图起始点
                    let startPoint = CGPoint(x: 0, y: geometry.size.height / 2)
                    path.move(to: startPoint)

                    // 绘制曲线
                    for i in 0..<ecgNotify.ecgData.count {
                        let xPosition = geometry.size.width * CGFloat(i) / CGFloat(ecgNotify.ecgData.count)
                        let yPosition = geometry.size.height / 2 - CGFloat(ecgNotify.ecgData[i]) * 100
                        let y = CGFloat(Double(ecgNotify.ecgData[i]) / 255.0) * CGFloat(geometry.size.height)
                        path.addLine(to: CGPoint(x: xPosition, y: geometry.size.height / 2 - y))
                    }
                }
                .stroke(Color.green, lineWidth: 1.5)
                
                // 增益信息
                Text("增益: 10 mm/mv")
                    .foregroundStyle(.white)
            }
        }
        .background(Color.black)
        
    }
    
     
    private func drawGrid(size: CGSize) -> some View {
        let horizontalLines = Int(size.height / 20)
        let verticalLines = Int(size.width / 20)
        
        return Path { path in
            // 水平线
            for i in 0...horizontalLines {
                let y = CGFloat(i) * size.height / CGFloat(horizontalLines)
                path.move(to: CGPoint(x: 0, y: y))
                path.addLine(to: CGPoint(x: size.width, y: y))
            }
            
            // 垂直线
            for i in 0...verticalLines {
                let x = CGFloat(i) * size.width / CGFloat(verticalLines)
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
            }
        }
        .stroke(Color.gray.opacity(0.3), lineWidth: 1) // 设置网格颜色和线宽
    }
}

#Preview {
    Ecg()
}
