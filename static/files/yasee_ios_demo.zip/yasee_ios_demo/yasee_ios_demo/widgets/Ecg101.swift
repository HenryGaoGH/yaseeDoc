//
//  Ecg101.swift
//  yasee_ios_demo
//
//  Created by Henry Gao on 2024/9/14.
//

import SwiftUI

struct Ecg101: View {
    @State private var ecgData: [CGFloat] = Array(repeating: 0.0, count: 500)
    private let gain: CGFloat = 10.0  // 10 mm/mV
    private let paperSpeed: CGFloat = 25.0  // 25 mm/s
    private let updateInterval: TimeInterval = 0.2  // 50 FPS

    
    func mmToPixels(mm: CGFloat) -> CGFloat {
        // 获取屏幕的 PPI（每英寸像素数）
        let screen = UIScreen.main
        let ppi = screen.scale * 163.0  // 163 是 1x 屏幕的 PPI，可以根据设备调整
        
        // 将 PPI 转换为每毫米的像素数
        let pixelsPerMm = ppi / 25.4  // 1 英寸 = 25.4 毫米
        
        return mm * pixelsPerMm
    }
    
    func voltageToPixels(voltage: CGFloat) -> CGFloat {
        // 将电压值转换为毫米，再转换为像素
        return mmToPixels(mm: voltage * gain)
    }
    
    
    
    var body: some View {
        Canvas { context, size in
            var path = Path()
            
            let pixelsPerMm = mmToPixels(mm: 1.0)
            let screenWidthInMm = size.width / pixelsPerMm
            
            // 每个点在 x 轴上的间隔
            let xInterval = screenWidthInMm / CGFloat(ecgData.count)
            
            path.move(to: CGPoint(x: 0, y: size.height / 2))
            
            // 绘制 ECG 曲线
            for (index, value) in ecgData.enumerated() {
                let x = CGFloat(index) * mmToPixels(mm: xInterval)
                let y = size.height / 2 - voltageToPixels(voltage: value)
                path.addLine(to: CGPoint(x: x, y: y))
            }
            
            // 绘制路径
            context.stroke(path, with: .color(.green), lineWidth: 2)
        }
        .frame(width: UIScreen.main.bounds.width, height: 300)
        .background(Color.black)
        .onAppear {
            Timer.scheduledTimer(withTimeInterval: updateInterval, repeats: true) { _ in
                updateECGData()
            }
        }
    }

    // 模拟 ECG 数据更新
    private func updateECGData() {
        let newData = (0..<135).map { _ in CGFloat.random(in: -1...1) }
        ecgData.append(contentsOf: newData)
        if ecgData.count > 135 {
            ecgData.removeFirst(ecgData.count - 135)
        }
    }
}

#Preview {
    Ecg101()
}
