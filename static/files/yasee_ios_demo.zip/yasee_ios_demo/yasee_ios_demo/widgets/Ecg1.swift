//
//  Ecg1.swift
//  yasee_ios_demo
//
//  Created by Henry Gao on 2024/9/25.
//

import SwiftUI




struct Ecg1: View {
    // 模拟心电图数据
    @StateObject
    private var ecgNotify = EcgNotify()
    
    var samplesPerSecond: CGFloat = 250.0   // 采样率
    var paperSpeed: CGFloat = 25.0          // 纸速
    var gain: CGFloat = 10                // 波形增益 mm/mV
    
    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height
            let step = paperSpeed / samplesPerSecond * width // 走纸速度和采样率决定的步长
            

            // 使用 Canvas 绘制心电图
            Canvas { context, size in
                var path = Path()
                path.move(to: CGPoint(x: 0, y: height / 2))

                for index in ecgNotify.ecgData.indices {
                    let xPosition = CGFloat(index) * step
                    let voltage = (ecgNotify.ecgData[index] / 255) // 假设 ecgData 中的值在 0 到 1 之间
                    let yPosition = height / 2 - (CGFloat(voltage) * gain) // 计算 y 坐标
                    path.addLine(to: CGPoint(x: xPosition, y: yPosition))
                }

                context.stroke(path, with: .color(.green), lineWidth: 2)
            }
            .background(Color.black)
        }
    }
}

#Preview {
    Ecg1(samplesPerSecond: 250, paperSpeed: 25)
}
