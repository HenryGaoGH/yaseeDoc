//
//  EcgNotify.swift
//  yasee_ios_demo
//
//  Created by Henry Gao on 2024/9/14.
//

import Foundation
import yasee_ios


class EcgNotify: ObservableObject {
    @Published 
    var ecgData: [Int] = []
    
    init() {
        let ecgCall: NotifyCall<NotifyDeviceData> = { data in
            guard
                let value = data.data.data["ecgData"]
            else { return }
            DispatchQueue.main.async {
                let vv = value.components(separatedBy: ",").map { Int($0 as String) ?? 0 }
                if self.ecgData.count > 7 * vv.count {
                    self.ecgData.removeSubrange(0..<vv.count)
                }
                self.ecgData.append(contentsOf: vv)
            }
        }
        Notify.single.listen(ecgCall)
    }
}
