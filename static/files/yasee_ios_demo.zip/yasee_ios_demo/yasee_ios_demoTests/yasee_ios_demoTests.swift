//
//  yasee_ios_demoTests.swift
//  yasee_ios_demoTests
//
//  Created by Henry Gao on 2024/8/2.
//

import XCTest
@testable import yasee_ios_demo
import yasee_ios

final class yasee_ios_demoTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        /// 设置 人员
        Yasee.single.currentUser = User(sex: 1, age: 24, smoking: 1, height: 178, weight: 65)
        
        /// 搜索蓝牙
        Yasee.single.scan()
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
