package com.yasee.yaseejava.tools;

import android.os.Handler;
import android.os.Looper;

/**
 * 通用防抖工具类
 *
 * 用于高频事件触发时，延迟执行最后一次操作
 */
public class DebounceRunner {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final long delayMillis;
    private Runnable runnable;

    /**
     * @param delayMillis 防抖延迟时间（毫秒）
     */
    public DebounceRunner(long delayMillis) {
        this.delayMillis = delayMillis;
    }

    /**
     * 提交任务，每次调用都会取消之前未执行的任务
     *
     * @param task 最终要执行的 Runnable
     */
    public void submit(Runnable task) {
        if (runnable != null) {
            handler.removeCallbacks(runnable);
        }

        runnable = task;
        handler.postDelayed(runnable, delayMillis);
    }

    /**
     * 立即取消当前防抖任务
     */
    public void cancel() {
        if (runnable != null) {
            handler.removeCallbacks(runnable);
            runnable = null;
        }
    }
}