package com.yasee.yaseejava.tools;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.Nullable;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.yasee.yasee.core.tools.BleDeviceTypeAdapter;

import java.lang.reflect.Type;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * PreferencesManager - Java-friendly replacement for DataStore for small key-value needs.
 * - 线程安全的单例
 * - 提供同步读取与异步写入（使用后台线程）
 * - 支持保存任意对象为 JSON（Gson）
 */
public class ToolLocalData {
    private static final String PREFS_NAME = "settings_prefs";
    private static volatile ToolLocalData instance;
    private final SharedPreferences prefs;
    private final Executor ioExecutor;
    private final Gson gson;

    // keys
    private static final String KEY_TOKEN = "key_token";
    private static final String KEY_FIRST_RUN = "key_first_run";
    private static final String KEY_LAST_DEVICE_LIST = "key_last_device_list"; // JSON

    private ToolLocalData(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        ioExecutor = Executors.newSingleThreadExecutor();
        gson = new GsonBuilder()
                .registerTypeAdapter(new TypeToken<BleDeviceTypeAdapter>() {}.getType(),new BleDeviceTypeAdapter())
                .create();
    }

    public static ToolLocalData getInstance(Context context) {
        if (instance == null) {
            synchronized (ToolLocalData.class) {
                if (instance == null) {
                    instance = new ToolLocalData(context);
                }
            }
        }
        return instance;
    }

    // ---------- Synchronous getters (safe on UI for cheap reads) ----------
    @Nullable
    public String getToken() {
        return prefs.getString(KEY_TOKEN, null);
    }

    public boolean isFirstRun() {
        return prefs.getBoolean(KEY_FIRST_RUN, true);
    }

    @Nullable
    public String getLastDeviceListJson() {
        return prefs.getString(KEY_LAST_DEVICE_LIST, null);
    }

    // Convenience: parse JSON to object list (example for List<DeviceModel>)
    // DeviceModel must be your POJO class
    @Nullable
    public <T> T getObject(String key, Class<T> clazz) {
        String json = prefs.getString(key, null);
        if (json == null) return null;
        return gson.fromJson(json, clazz);
    }

    /**
     * Generic for List<T> deserialization:
     * Type type = new TypeToken<List<DeviceModel>>() {}.getType();
     * List<DeviceModel> list = preferencesManager.getObjectList(KEY_LAST_DEVICE_LIST, type);
     */
    @Nullable
    public <T> T getObjectWithType(String key, Type typeOfT) {
        String json = prefs.getString(key, null);
        if (json == null) return null;
        try {
            T t = gson.fromJson(json, typeOfT);
            return t;
        } catch (JsonSyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    // ---------- Async setters (do writes off main thread) ----------
    public void setToken(final String token) {
        ioExecutor.execute(new Runnable() {
            @Override
            public void run() {
                prefs.edit().putString(KEY_TOKEN, token).apply();
            }
        });
    }

    public void setFirstRun(final boolean firstRun) {
        ioExecutor.execute(new Runnable() {
            @Override
            public void run() {
                prefs.edit().putBoolean(KEY_FIRST_RUN, firstRun).apply();
            }
        });
    }

    public void setLastDeviceListJson(final String json) {
        ioExecutor.execute(new Runnable() {
            @Override
            public void run() {
                if (json == null) {
                    prefs.edit().remove(KEY_LAST_DEVICE_LIST).apply();
                } else {
                    prefs.edit().putString(KEY_LAST_DEVICE_LIST, json).apply();
                }
            }
        });
    }

    public <T> void putObject(final String key, final T obj) {
        final String json = gson.toJson(obj);
        ioExecutor.execute(new Runnable() {
            @Override
            public void run() {
                prefs.edit().putString(key, json).apply();
            }
        });
    }

    // ---------- Utility ----------
    public void clearAll() {
        ioExecutor.execute(new Runnable() {
            @Override
            public void run() {
                prefs.edit().clear().apply();
            }
        });
    }
}