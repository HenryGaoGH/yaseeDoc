package com.yasee.yaseejava;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.yasee.yasee.Notify;
import com.yasee.yasee.Yasee;
import com.yasee.yasee.core.models.AdvertisementData;
import com.yasee.yasee.core.models.ParmsModel;
import com.yasee.yasee.protocols.ble.BleDevice;
import com.yasee.yasee.core.enums.BleProcess;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yasee.core.configs.BleConfig;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yaseejava.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.PopupMenu;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    static List<BleDevice> binds = new ArrayList<>();
    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (checkBLEConnectionPermission()) {
            Log.d("权限","有相关的权限");
            Yasee.getSingle().setContext(getApplicationContext());
        } else {
            requestBLEConnectionPermission();
        }

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Yasee.getSingle().setContext(getApplicationContext());
                Yasee.getSingle().bleConfig = new BleConfig(5);
                Yasee.getSingle().scan();
            }
        });

        binding.filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 创建PopupMenu
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, view);
                popupMenu.getMenu().add("tmd");
                popupMenu.getMenu().add("hlw");
                popupMenu.getMenu().add("wl");
                popupMenu.getMenu().add("yc");
                // 设置菜单项的点击监听器
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        Fragment navHostFragment = getSupportFragmentManager().getFragments().get(0);

                        if (navHostFragment instanceof NavHostFragment) {
                            ScanFragment currentFragment = (ScanFragment) navHostFragment.getChildFragmentManager().getPrimaryNavigationFragment();
                            if (currentFragment != null) {
                                Log.d("CurrentFragment", "当前 Fragment 是: " + currentFragment.getClass().getSimpleName());
                                currentFragment.filter(item.getTitle());
                            }
                        }
                        return false;
                    }
                });

                // 显示PopupMenu
                popupMenu.show();
            }
        });


        Notify.getSingle().listen(_state);
        // 远程绑定设备
        binding.linkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mac = binding.macInput.getText().toString();
                BleDevice bd =  new BleDevice(mac,"Y917-"+mac.substring(12), new AdvertisementData(new HashMap<>()));
                bd.connect();
            }
        });


        try {
            testSerial();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @SuppressLint("ResourceType")
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent _binds = new Intent(MainActivity.this, SerialActivity.class);
            startActivity(_binds);
            return true;
        } else if (id == R.id.action_masschip) { // 白细胞
            Intent _mc = new Intent(MainActivity.this, Masschip.class);
            startActivity(_mc);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private void requestBLEConnectionPermission() {
        String[] arrayPermission;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayPermission = new String[]{android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_SCAN};
        } else {
            arrayPermission = new String[]{
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION,
                android.Manifest.permission.BLUETOOTH_SCAN,
                android.Manifest.permission.BLUETOOTH_CONNECT,
            };
        }
        ActivityCompat.requestPermissions(this, arrayPermission, 1111);
    }


    private boolean checkBLEConnectionPermission() {
        boolean isGranted = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED) {
                isGranted = true;
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                isGranted = true;
            }
        } else {
            isGranted = true;
        }
        return isGranted;
    }



    NotifyInterface _state = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceLink;
        }
        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleLink bleLink = (NotifyResp.BleLink) data.data;
            if (bleLink.process != BleProcess.linked) return;
            Bundle _bd = new Bundle();
            _bd.putString("mac",((BleDevice) ((NotifyResp.BleLink) data.data).device).getMac());
        }
    };




    /*
    * test serial
    * */
    void testSerial() throws IOException {

    }

}