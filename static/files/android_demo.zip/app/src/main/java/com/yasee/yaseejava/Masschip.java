package com.yasee.yaseejava;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.yasee.yasee.Notify;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yasee.core.tools.ByteTool;
import com.yasee.yasee.core.tools.Logs;
import com.yasee.yasee.platforms.masschip.PlatformMasschip;
import com.yasee.yaseejava.databinding.ActivityMasschipBinding;
import com.yasee.yaseejava.databinding.ActivitySerialBinding;

public class Masschip extends AppCompatActivity {

    private ActivityMasschipBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_masschip);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });

        Notify.getSingle().listen(_ni);

        PlatformMasschip.getInstance().search();


        binding = ActivityMasschipBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());

        binding.masschipStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PlatformMasschip.getInstance().startCheck();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Notify.getSingle().remove(_ni);
    }

    NotifyInterface _ni = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceData;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleNotifyData ssss = (NotifyResp.BleNotifyData) data.data;
            String _s = ssss.dataToJson();
            String text = String.format("%s\n start============\n   指令可视化数据:%s\nend================\n", binding.masschipResult.getText(), _s);
            Logs.print(text);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    binding.masschipResult.setText(text);
                }
            });
        }
    };


}