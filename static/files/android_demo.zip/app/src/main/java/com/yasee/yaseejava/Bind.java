package com.yasee.yaseejava;

import android.app.Activity;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.yasee.yasee.Notify;
import com.yasee.yasee.ble.BleDevice;
import com.yasee.yasee.core.enums.BleProcess;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yaseejava.adapters.BleItemsAda;
import com.yasee.yaseejava.databinding.ActivityBindBinding;
import com.yasee.yaseejava.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class Bind extends AppCompatActivity {

    ActivityBindBinding binding;
    private RecyclerView recyclerView;
    private BleItemsAda myAdapter = new BleItemsAda(new ArrayList<>(), new BleItemsAda.ItemClickListener() {
        @Override
        public void onItemClick(BleDevice item) {
//            if(item.getBleProcess() != BleProcess.unlink) {
//                NavHostFragment.findNavController(ScanFragment.this)
//                        .navigate(R.id.action_FirstFragment_to_BleInfo);
//                return;
//            }
//            item.connect();
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityBindBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        recyclerView = binding.bindList;
        recyclerView.setLayoutManager(new LinearLayoutManager(Bind.this));


        // Initialize the adapter and set it to the RecyclerView
        recyclerView.setAdapter(myAdapter);


        Notify.getSingle().listen(_devices);



    }


    NotifyInterface _devices = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.bindDevices;
        }
        @Override
        public void message(NotifyResp data) {
            myAdapter.setItems((List<BleDevice>) data.data);
        }
    };
}