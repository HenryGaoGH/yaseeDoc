package com.yasee.yaseejava;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.yasee.yasee.Yasee;
import com.yasee.yasee.ble.Devices;
import com.yasee.yasee.core.enums.BleProcess;
import com.yasee.yasee.core.models.Check;
import com.yasee.yasee.core.models.Cmd;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yasee.core.tools.Logs;
import com.yasee.yasee.Notify;
import com.yasee.yasee.core.abstracts.Platforms;
import com.yasee.yasee.core.tools.Products;
import com.yasee.yasee.ble.BleDevice;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yaseejava.adapters.ChecksAda;
import com.yasee.yaseejava.databinding.BleInfoBinding;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class BleInfo extends Fragment {

    private BleInfoBinding binding;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = BleInfoBinding.inflate(inflater, container, false);

        Notify.getSingle().listen(_ni);
        Notify.getSingle().listen(_link);

        binding.closeBle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Devices.getSingle().delWithMac(BleDevice.current.getMac());
            }
        });

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<Check> ccs = Products.supportChecks(BleDevice.current);

        binding.deviceName.append(BleDevice.current.getModel());
        binding.supportsCheck.setAdapter(new ChecksAda(getActivity(), ccs));
        binding.supportsCheck.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            private int _last = -1;
            private int _step = 0;
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Check cc = ccs.get(position);
                List<Cmd> cmds = cc.getCmds();

                // 创建PopupMenu
                PopupMenu popupMenu = new PopupMenu(BleInfo.this.getContext(), view);

                // 添加菜单项
                cmds.forEach(cmd -> {
                    popupMenu.getMenu().add(0,cmds.indexOf(cmd),0,cmd.desc);
                });
                if (cc.name.contains("心电")) {
                    popupMenu.getMenu().add("30秒");
                    popupMenu.getMenu().add("1分钟");
                    popupMenu.getMenu().add("24小时");
                    popupMenu.getMenu().add("结束1分钟");
                }


                // 设置菜单项的点击监听器
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getTitle().equals("30秒")) {
                            HashMap map = new HashMap<String, Object>();
                            map.put("time",30);
                            BleDevice.current.send(cc.handwareCode,cmds.get(0).id,map);
                        } else if (item.getTitle().equals("1分钟")) {
                            HashMap map = new HashMap<String, Object>();
                            map.put("time",60);
                            BleDevice.current.send(cc.handwareCode,cmds.get(0).id,map);
                        } else if (item.getTitle().equals("24小时")) {
                            HashMap map = new HashMap<String, Object>();
                            map.put("time",24 * 60 * 60);
                            BleDevice.current.send(cc.handwareCode,cmds.get(0).id,map);
                        } else if (item.getTitle().equals("结束1分钟")) {
                            HashMap map = new HashMap<String, Object>();
                            map.put("time",60);
                            BleDevice.current.send(cc.handwareCode,cmds.get(1).id,map);
                        } else {
                            HashMap map = new HashMap<String, Object>();
                            map.put("time",24 * 60 * 60);
                            map.put("startTime",(System.currentTimeMillis()));
                            BleDevice.current.send(cc.handwareCode,cmds.get(item.getItemId()).id,map);
                        }
                        return false;
                    }
                });

                // 显示PopupMenu
                popupMenu.show();

            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Notify.getSingle().remove(_ni);
        Notify.getSingle().remove(_link);
        binding = null;
    }

    NotifyInterface _ni = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceData;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleNotifyData ssss = (NotifyResp.BleNotifyData) data.data;
            String _sss = "本次"; //binding.sendData.getText().toString();
//            if (ssss.clearData.getDecodeData() instanceof Resp) {
//
//            } else if (ssss.clearData.getDecodeData() instanceof HashMap) {
//
//            }
            HashMap _s = (HashMap) ssss.data;
            String text = String.format("%s\n start============\n  原始: %s\n  指令类型:%s \n  指令可视化数据:%s\nend================\n", binding.sendData.getText(),Arrays.toString(ssss.raw),ssss.step.name(), _s==null ? "" : _s.toString());
            Logs.print(text);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    binding.sendData.setText(text);
                }
            });
        }
    };
    NotifyInterface _link = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceLink;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleLink _data = (NotifyResp.BleLink) data.data;
            binding.closeBle.setText(_data.device.getBleProcess() == BleProcess.unlink ? "未连接" : "已连接");
        }
    };
}