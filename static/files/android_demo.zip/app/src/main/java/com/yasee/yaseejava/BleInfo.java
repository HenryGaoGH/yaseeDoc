package com.yasee.yaseejava;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.yasee.yasee.Yasee;
import com.yasee.yasee.ble.Devices;
import com.yasee.yasee.core.enums.BleProcess;
import com.yasee.yasee.core.models.Check;
import com.yasee.yasee.core.models.Cmd;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yasee.core.tools.Logs;
import com.yasee.yasee.Notify;
import com.yasee.yasee.core.abstracts.Platforms;
import com.yasee.yasee.core.tools.Products;
import com.yasee.yasee.ble.BleDevice;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yaseejava.adapters.ChecksAda;
import com.yasee.yaseejava.databinding.BleInfoBinding;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class BleInfo extends Fragment {

    private BleInfoBinding binding;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = BleInfoBinding.inflate(inflater, container, false);

        Notify.getSingle().listen(_ni);
        Notify.getSingle().listen(_link);

        binding.closeBle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Devices.getSingle().delWithMac(BleDevice.current.getMac());
            }
        });

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<Check> ccs = Products.supportChecks(BleDevice.current);

        binding.deviceName.append(BleDevice.current.getModel());
        binding.supportsCheck.setAdapter(new ChecksAda(getActivity(), ccs));
        binding.supportsCheck.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            private int _last = -1;
            private int _step = 0;
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(_last != position) _step = 0;

                Check cc = ccs.get(position);
                Cmd cmd = cc.getCmds().get(_step);
                BleDevice.current.send(cc.handwareCode,cmd.id);
//                if (position == 0) {
//
//
//                    BleDevice.current.send(_pf.getCheckSign().sign(_last == position ? TmdCmds.Bp.stop : TmdCmds.Bp.start));
//                } else if (position == 4) {
//                    Platforms _pf = BleDevice.current.getPlatform();
//                    BleDevice.current.send(_pf.getCheckSign().sign(_last == position ? TmdCmds.Ub.stop : TmdCmds.Ub.start));
//                } else if (position == 10) {
//                    Platforms _pf = BleDevice.current.getPlatform();
//                    if (_step == 0) { // 设置人员
//                        BleDevice.current.send(_pf.getCheckSign().sign(TmdCmds.Pb.setUser));
//                    } else if (_step == 1) { // 快速测量
//                        BleDevice.current.send(_pf.getCheckSign().sign(TmdCmds.Pb.start));
//                    } else if (_step == 3) { // 获取气温等信息
//                        BleDevice.current.send(_pf.getCheckSign().sign(TmdCmds.Pb.thp));
//                    } else if (_step == 2) { // 获取波点
//                        BleDevice.current.send(_pf.getCheckSign().sign(TmdCmds.Pb.points));
//                    } else _step = -1;
//                } else if (position == 7) {
//                    Platforms _pf = BleDevice.current.getPlatform();
//                    BleDevice.current.send(_pf.getCheckSign().sign(TmdCmds.Ox.start));
//                } else if (position == 9) {
//                    Platforms _pf = BleDevice.current.getPlatform();
//                    if (_step == 0) {
//                        BleDevice.current.send(_pf.getCheckSign().sign(TmdCmds.Ch.start));
//                    } else if (_step == 1) {
//                        BleDevice.current.send(_pf.getCheckSign().sign(TmdCmds.Ch.code));
//                    }
//                } else if (position == 16) { // 测试 Devices 连接属性
////                    List<BleDevice> dds = Devices.getSingle().getDevices();
////                    List<BleDevice> linkeds = Devices.getSingle().getLinkeds();
////                    binding.sendData.setText(String.format("%s\n  绑定数:%d\n  连接数:%d\n  当前连接设备:%s",binding.sendData.getText(),dds.size(),linkeds.size(),linkeds.size() == 0 ? "0个设备" : linkeds.get(0).getModel()));
//                }
//                _last = position;
//                _step ++;
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Notify.getSingle().remove(_ni);
        Notify.getSingle().remove(_link);
        binding = null;
    }

    NotifyInterface _ni = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceData;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleNotifyData ssss = (NotifyResp.BleNotifyData) data.data;
            String _sss = binding.sendData.getText().toString();
//            if (ssss.clearData.getDecodeData() instanceof Resp) {
//
//            } else if (ssss.clearData.getDecodeData() instanceof HashMap) {
//
//            }
            HashMap _s = (HashMap) ssss.data;
            String text = String.format("%s\n start============\n  原始: %s\n  指令类型:%s \n  指令可视化数据:%s\nend================", _sss,Arrays.toString(ssss.raw),ssss.step.name(), _s==null ? "" : _s.toString());
            Logs.print(text);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    binding.sendData.setText(text);
                }
            });
        }
    };
    NotifyInterface _link = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceLink;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleLink _data = (NotifyResp.BleLink) data.data;
            binding.closeBle.setText(_data.device.getBleProcess() == BleProcess.unlink ? "未连接" : "已连接");
        }
    };

}