package com.yasee.yaseejava;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.yasee.yasee.Devices;
import com.yasee.yasee.core.enums.CmdType;
import com.yasee.yasee.core.models.ParmsModel;
import com.yasee.yasee.core.models.Check;
import com.yasee.yasee.core.models.Cmd;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yasee.Notify;
import com.yasee.yasee.core.tools.Logs;
import com.yasee.yasee.core.tools.Products;
import com.yasee.yasee.protocols.ble.BleDevice;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yaseejava.adapters.ChecksAda;
import com.yasee.yaseejava.databinding.BleInfoBinding;
import com.yasee.yaseejava.tools.DebounceRunner;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BleInfo extends Fragment {

    private BleInfoBinding binding;

    ///  是不是展示脉诊
    private boolean _canMz = false;

    ///  CGM结果存储
    private List<String> _cgmArr = new ArrayList<>();
    private DebounceRunner debounceRunner = new DebounceRunner(200);


    private BleDevice bleDevice;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = BleInfoBinding.inflate(inflater, container, false);
        Bundle args = getArguments();
        bleDevice = Devices.getSingle().getDeviceWithMac((String) args.get("mac"));
        Notify.getSingle().listen(_ni);
        Notify.getSingle().listen(_link);
        Notify.getSingle().listen(_history);
        _cgmArr.add("序号,值,hex\n");

        binding.closeBle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Devices.getSingle().delWithMac(bleDevice.getMac());
                if (bleDevice.getState() == 0) {
                    bleDevice.connect();
                } else {
                    binding.closeBle.setText("未连接");
                    bleDevice.disConnect();
                }
            }
        });

        binding.clearLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.sendData.setText("");
                binding.sendDataNoMsg.setText("");
                binding.ecgCun.clean();
                binding.ecgGuan.clean();
                binding.ecgChi.clean();
            }
        });

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        List<Check> ccs = Products.supportChecks(bleDevice);

        // 是否展示 脉诊信息UI
        for (Check cc : ccs) {
            if (cc.name.equals("脉诊仪") || cc.name.equals("脉诊仪(自研)")) { _canMz = true; }
        }


        binding.deviceName.append(bleDevice.getModel());
        binding.ecgView.setVisibility( _canMz ? View.VISIBLE : View.GONE);
        binding.supportsCheck.setAdapter(new ChecksAda(getActivity(), ccs));
        binding.supportsCheck.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            private int _last = -1;
            private int _step = 0;
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Check cc = ccs.get(position);
                List<Cmd> cmds = cc.getCmds();

                // 创建PopupMenu
                PopupMenu popupMenu = new PopupMenu(BleInfo.this.getContext(), view);

                // 添加菜单项
                cmds.forEach(cmd -> {
                    popupMenu.getMenu().add(0,cmds.indexOf(cmd),0,cmd.desc);
                });
                if (cc.name.equals("心电")) {
                    popupMenu.getMenu().add("30秒");
                    popupMenu.getMenu().add("1分钟");
                    popupMenu.getMenu().add("24小时");
                    popupMenu.getMenu().add("结束1分钟");
                } else if (cc.name.equals("血脂")) {
                    // 9204
                    popupMenu.getMenu().add("对码步骤1");
                    popupMenu.getMenu().add("对码步骤2");

                    // 8092
                    popupMenu.getMenu().add("对码步骤3");
                    popupMenu.getMenu().add("对码步骤4");

                } else if (cc.name.equals("糖化血红蛋白")) {
                    popupMenu.getMenu().add("糖化对码");
                }
                else if (cc.name.equals("同步&删除")) {
                    // 步数 0, 睡眠 1,心率 2, 血压 3, 血氧 呼吸率 hrv 温度 血糖 4, 运动模式历史数据 5,后台提醒记录数据 6
                    popupMenu.getMenu().add("步数(history)");
                    popupMenu.getMenu().add("睡眠(history)");
                    popupMenu.getMenu().add("心率(history)");
                    popupMenu.getMenu().add("血压(history)");
                    popupMenu.getMenu().add("血氧呼吸率hrv温度血糖");
                    popupMenu.getMenu().add("运动模式历史数据");
                } else if (cc.name.equals("体温")) {
                    popupMenu.getMenu().add("腋下");
                    popupMenu.getMenu().add("口腔");
                    popupMenu.getMenu().add("肛门");
                    popupMenu.getMenu().add("额头");
                } else if (cc.name.equals("YaseeCGM") || cc.name.equals("动态体温")) { //
                    popupMenu.getMenu().add("导出");
                }


                // 设置菜单项的点击监听器
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        ParmsModel parms = new ParmsModel();
                        if (item.getTitle().equals("对码步骤1")) {
//                            String hexString = "AA55C9840420000000C0420114081B010101010200011000089c00EB27C700569246CC0455C57b646044416045C100477ec800c2814666e2d1c50080954483c050c10000000000000000009040c600c2814666e2d1c566d604459a998fc2002c5946009871c69ab1ba4529dc3a43a167a33f0000000000000000cdccfdc31fd54a44c5202bc23d8ae3432bf6ef3fc3f566c30ad730442b87bbc233530044bf7d8d400000000000000000000F00140019001E0023000000000000000F00140019001E00230000000000003BCA";
                            String hexString = "AA55C9840420000000C0420A180C020C01010101000010002499006B47C70092C846661A87C5F6984944560E4FC1002203C800B656473327E9C50A77734489413AC1000000000000000033C7ADC500A8AF45003088C48FD27344EC51EFC15C0FB5C39A5D9EC59ACDA945AE279EC323DBE24100000000000000000080ABC466EE2E45CD6CB1C49AB93844AAF1BEC185AB17C49AD99144E13A9BC3CD6CE643A779A1400000000000000000000F00130018001E0023000000000000000F00130018001E00230000000000003F54";
                            // 步骤2: 创建byte数组
                            int length = hexString.length(); // 获取输入字符串的长度
                            byte[] byteArray = new byte[length / 2]; // 创建byte数组，长度为输入字符串长度的一半

                            // 步骤3: 转换字符并存储到byte数组中
                            for (int i = 0; i < length; i += 2) {
                                String subString = hexString.substring(i, i + 2); // 取出两个字符
                                byte byteValue = (byte) Integer.parseInt(subString, 16); // 转换为byte值
                                byteArray[i / 2] = byteValue; // 存储到byte数组中
                            }
                            bleDevice.send(byteArray,false);
                        } else if (item.getTitle().equals("对码步骤2")) {
//                            String hexString = "AA55C984042100C000C0c1a8a4bc95d4c13fd04458bb05a38a3f9d80563ff4fdd43b933aa93ff4fd54bcfaed6bbc2d21af3fe02d10bb7424873f7dae463fbc74133c93a9a23fea9532bca69b44bc508da73f04e78c3bb3ea633f1058793f6f12833ac9e5cf3f849ecdbc849ecdbcc9e5cf3f6f12833a1058793fb3ea633f04e78c3b508da73fa69b44bcea9532bc93a9a23fbc74133c7dae463f7424873fe02d10bb2d21af3ffaed6bbcf4fd54bc933aa93ff4fdd43b9d80563f05a38a3fd04458bb95d4c13fc1a8a4bc6473";
                            String hexString = "AA55C984042100C000C0006F01BDE10BD33F52491DBA68227C3F865A53BC8716A93F0AD723BBD7347F3FD7346FBC091BB63F8C4AEABCDC46DB3FD044D8BBBDE3943FE02D903B8A1F533FE71DA7BC17B7B93F6519E2BB7B14963FED0DBEBBDE71923F89D25E3C0C020B3FF5B9DABC8FE4CA3F75021ABC567D9E3F96438BBCC74BB73F99BB16BC5C20993F05A392BC075FC03F6519E2BC3789D93F62A156BC516BAA3FB37B72BB764F863F7CF230BC6A4DA33FC6DC35BCBF0EA43FA69B44BBDCD7893FA69B44BB6EA3893F5E1E";
                            // 步骤2: 创建byte数组
                            int length = hexString.length(); // 获取输入字符串的长度
                            byte[] byteArray = new byte[length / 2]; // 创建byte数组，长度为输入字符串长度的一半

                            // 步骤3: 转换字符并存储到byte数组中
                            for (int i = 0; i < length; i += 2) {
                                String subString = hexString.substring(i, i + 2); // 取出两个字符
                                byte byteValue = (byte) Integer.parseInt(subString, 16); // 转换为byte值
                                byteArray[i / 2] = byteValue; // 存储到byte数组中
                            }
                            bleDevice.send(byteArray,false);
                        } else if (item.getTitle().equals("对码步骤3")) {
                            String hexString = "AA55C9840420000000C0420A19021A020101010100001000CC94406249C8006DCE4700548CC69A59D444E5D0E9C120F198C8C0B10B480032AAC66626E6440000D6C10000000000000000002A13C7000D424700C2A1C666628345AE0743C300DADFC600280547001845C6CD342B457B94F6C200000000000000006652C2C5003C3D46CD98E8C5CDE40C45D7A308C3007433C60006A04600C438C633DB4845856B44C30000000000000000000F00130018001E0023000000000000000F00130018001E0023000000000000391E";
                            // 步骤2: 创建byte数组
                            int length = hexString.length(); // 获取输入字符串的长度
                            byte[] byteArray = new byte[length / 2]; // 创建byte数组，长度为输入字符串长度的一半

                            // 步骤3: 转换字符并存储到byte数组中
                            for (int i = 0; i < length; i += 2) {
                                String subString = hexString.substring(i, i + 2); // 取出两个字符
                                byte byteValue = (byte) Integer.parseInt(subString, 16); // 转换为byte值
                                byteArray[i / 2] = byteValue; // 存储到byte数组中
                            }
                            bleDevice.send(byteArray,false);
                        } else if (item.getTitle().equals("对码步骤4")) {
                            String hexString = "AA55C984042100C000C02E90A0BD9BE62940499D80BC8AB0B13FB00367BCED9EAC3FAC8B5BBCCCEEA93F60E5D0BC50FCD03F3D2CD4BCE336D23FE71DA7BC1283C03F17B751B95DDC663F2E90A0BC7671BB3F211F74BC643BAF3F75021ABC8BFD9D3F27A0093BE63F643F787AA5BD022B2B40CDCC4CBCA2B4A73FE3A51BBC143F9E3F6C0979BC1AC0B33F265385BD3B701640E71D27BCBC96A03F38F8C2BC71ACCB3F1EA7E83B04E72C3F52499D3A66888B3FA69BC4BC7446CC3F865AD3BC2EFFD13FD044583CBEC1F73E609F";
                            // 步骤2: 创建byte数组
                            int length = hexString.length(); // 获取输入字符串的长度
                            byte[] byteArray = new byte[length / 2]; // 创建byte数组，长度为输入字符串长度的一半

                            // 步骤3: 转换字符并存储到byte数组中
                            for (int i = 0; i < length; i += 2) {
                                String subString = hexString.substring(i, i + 2); // 取出两个字符
                                byte byteValue = (byte) Integer.parseInt(subString, 16); // 转换为byte值
                                byteArray[i / 2] = byteValue; // 存储到byte数组中
                            }
                            bleDevice.send(byteArray,false);
                        }
                        else if (item.getTitle().equals("30秒")) {
                            parms.time = 30;
                            bleDevice.send(cc,cmds.get(0).id,parms);
                        } else if (item.getTitle().equals("1分钟")) {
                            parms.time = 60;
                            bleDevice.send(cc,cmds.get(0).id,parms);
                        }
                        else if (item.getTitle().equals("24小时")) {
                            parms.time = 24 * 60 * 60;
                            bleDevice.send(cc,cmds.get(0).id,parms);
                        } else if (item.getTitle().equals("结束1分钟")) {
                            parms.time = 60;
                            bleDevice.send(cc,cmds.get(1).id,parms);
                        }
                        else if (item.getTitle().equals("同步时间")) {
                            bleDevice.send(cc,cmds.get(0).id,parms);
                        } else if (item.getTitle().equals("单位设置")) {
                            parms.distanceUnit = 1;
                            parms.weightUnit = 1;
                            parms.temperatureUnit = 1;
                            parms.timeFormat = 1;
                            parms.bloodSugarUnit = 1;
                            parms.uricAcidUnit = 1;
                            bleDevice.send(cc,cmds.get(1).id,parms);
                        }
                        else if (item.getTitle().equals("语言设置")) {
                            parms.langType = 2;
                            bleDevice.send(cc,cmds.get(1).id,parms);
                        } else if (item.getTitle().equals("温度报警设置")) {
                            parms.on_off = true;
                            parms.maxTempInteger = 38;
                            parms.minTempInteger = 36;
                            parms.maxTempFloat = 5;
                            parms.minTempFloat = 0;
                            bleDevice.send(cc,cmds.get(1).id,parms);
                        }
                        else if (item.getTitle().equals("同步数据")) {
                            parms.dataType = 2;
                            bleDevice.send(cc,cmds.get(0).id,parms);
                        } else if (item.getTitle().equals("删除数据")) {
                            parms.dataType = 12;
                            bleDevice.send(cc,cmds.get(1).id,parms);
                        }
                        else if (item.getTitle().equals("开始测量(yc)")) {
                            parms.testType = 4;
                            parms.on_off = true;
                            bleDevice.send(cc,cmds.get(0).id,parms);
                        } else if (item.getTitle().equals("监测模式(yc)")) {
                            parms.testType = 4;
                            parms.on_off = false;
                            parms.time = 60;
                            bleDevice.send(cc,cmds.get(1).id,parms);
                        }
                        else if (item.getTitle().equals("结束测量(yc)")) {
                            parms.testType = 4;
                            parms.on_off = false;
                            bleDevice.send(cc,cmds.get(2).id,parms);
                        } else if (item.getTitle().equals("设置左右手")) {
                            parms.leftOrRight = 1;
                            bleDevice.send(cc,cmds.get(1).id,parms);
                        }
                        else if (item.getTitle().equals("糖化对码")) {
                            String hexString = "AA5535850CD4CC092B30302E3030303134362D30302E3031333836302B30302E3539353930362D30342E3339373235383233313231320B5D";
                            // 步骤2: 创建byte数组
                            int length = hexString.length(); // 获取输入字符串的长度
                            byte[] byteArray = new byte[length / 2]; // 创建byte数组，长度为输入字符串长度的一半

                            // 步骤3: 转换字符并存储到byte数组中
                            for (int i = 0; i < length; i += 2) {
                                String subString = hexString.substring(i, i + 2); // 取出两个字符
                                byte byteValue = (byte) Integer.parseInt(subString, 16); // 转换为byte值
                                byteArray[i / 2] = byteValue; // 存储到byte数组中
                            }
                            bleDevice.send(byteArray,false);
                        } else if (item.getTitle().equals("步数(history)")) {
                            parms.dataType = 0;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }
                        else if (item.getTitle().equals("睡眠(history)")) {
                            parms.dataType = 1;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        } else if (item.getTitle().equals("心率(history)")) {
                            parms.dataType = 2;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }
                        else if (item.getTitle().equals("血压(history)")) {
                            parms.dataType = 3;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        } else if (item.getTitle().equals("血氧呼吸率hrv温度血糖")) {
                            parms.dataType = 4;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }
                        else if (item.getTitle().equals("运动模式历史数据")) {
                            parms.dataType = 5;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        } else if (item.getTitle().equals("运动控制(start|stop)")) {
                            parms.sportSwitch = 1;
                            parms.sportType = 8;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }
                        else if (item.getTitle().equals("运动实时数据(on|off)")) {
                            parms.sportRealOpen = true;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }  else if (item.getTitle().equals("历史详情(仅限支持的设备:GLM)")) {
                            parms.historyIndex = 1;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }
                        else if (item.getTitle().equals("开始测量(左|右)")) {
                            parms.leftOrRight = 1;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }else if (item.getTitle().equals("波形开关")) {
                            parms.on_off = true;
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        } else if (item.getTitle().equals("腋下")) {
                            parms.commEnum = 0;
                            bleDevice.send(cc,cmds.get(3).id,parms);
                        }  else if (item.getTitle().equals("口腔")) {
                            parms.commEnum = 1;
                            bleDevice.send(cc,cmds.get(3).id,parms);
                        } else if (item.getTitle().equals("肛门")) {
                            parms.commEnum = 2;
                            bleDevice.send(cc,cmds.get(3).id,parms);
                        } else if (item.getTitle().equals("额头")) {
                            parms.commEnum = 3;
                            bleDevice.send(cc,cmds.get(3).id,parms);
                        } else if (item.getTitle().equals("导出")) {
                            writeToDownload(getContext(),_cgmArr,"yasee-cgm");
                        } else {
                            bleDevice.send(cc,cmds.get(item.getItemId()).id,parms);
                        }
                        return false;
                    }
                });

                // 显示PopupMenu
                popupMenu.show();

            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Notify.getSingle().remove(_ni);
        Notify.getSingle().remove(_link);
        Notify.getSingle().remove(_history);
        binding = null;
    }

    NotifyInterface _ni = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceData;
        }

        @Override
        public void message(NotifyResp data) {
            if(binding== null) return;
            NotifyResp.BleNotifyData ssss = (NotifyResp.BleNotifyData) data.data;

            if (_canMz && ssss.step == CmdType.countDown) {
                int index = Integer.parseInt((String) ((HashMap) ssss.data).get("codeIndex"));
                Float cun = (Float) ((HashMap) ssss.data).get("cun");
                Float guan = (Float) ((HashMap) ssss.data).get("guan");
                Float chi = (Float) ((HashMap) ssss.data).get("chi");
                binding.ecgCun.setBaselineLevel(index);
                binding.ecgGuan.setBaselineLevel(index);
                binding.ecgChi.setBaselineLevel(index);
                binding.ecgCun.addEcgData(cun);
                binding.ecgGuan.addEcgData(guan);
                binding.ecgChi.addEcgData(chi);

                Float cunG = (Float) ((HashMap) ssss.data).get("cunG");
                Float guanG = (Float) ((HashMap) ssss.data).get("guanG");
                Float chiG = (Float) ((HashMap) ssss.data).get("chiG");
                binding.ecgCgc.setText(String.format("寸: %.2f 关: %.2f  尺: %.2f",cunG,guanG,chiG));

                return;
            }

            // CGM 结果存储
            if (ssss.step == CmdType.result && ssss.device.getModel().startsWith("Yasee") || ssss.device.getModel().startsWith("Y920") || ssss.device.getModel().startsWith("YS2") && ssss.step == CmdType.countDown) {
                HashMap<String,String> _map = (HashMap) ssss.data;
                _cgmArr.add(String.format("%d,%s,%s,",_cgmArr.size()-1,_map.getOrDefault("value","--"),_map.getOrDefault("raw","--")));
            }

            String _s = ssss.dataToJson();
            String _lastText = ssss.step == CmdType.message ? binding.sendData.getText().toString() : binding.sendDataNoMsg.getText().toString();
            String text = String.format("%s\n start============\n  指令类型:%s \n  指令可视化数据:%s\nend================\n",_lastText,ssss.step.name(), _s==null ? "" : _s);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    if(binding == null) return;
                    if (ssss.step == CmdType.message) {
                        binding.sendData.setText(text);
                    } else {
                        binding.sendDataNoMsg.setText(text);
                    }

                }
            });
        }
    };
    NotifyInterface _link = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceLink;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleLink _data = (NotifyResp.BleLink) data.data;
            binding.closeBle.setText(((BleDevice) _data.device).getState() == 0 ? "未连接" : "已连接");
        }
    };

    private StringBuilder sb = new StringBuilder("");
    NotifyInterface _history = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.testHistory;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleHistoryData ssss = (NotifyResp.BleHistoryData) data.data;

            String _c = String.format("\nhistory============\n       历史数据接收数量:%d\n       内容:%s  \nend================\n",
                    ssss.data.size(),
                    ssss.data.toString());

            Logs.print(_c);

            sb.append(_c);

            final String newText = sb.toString();

            debounceRunner.submit(() -> {
                binding.sendData.setText(newText);
            });
            new Handler(Looper.getMainLooper()).post(() -> {

            });
        }
    };


    /**
     * 导出到文件
     * */
    private void writeToDownload(Context context, List<String> data, String fileName) {
        ContentResolver resolver = context.getContentResolver();

        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, "text/csv");

        // RELATIVE_PATH 只适用 API 29+
        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        Uri uri = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        }
        if (uri == null) {
            Toast.makeText(context, "无法保存到下载文件夹", Toast.LENGTH_SHORT).show();
            return;
        }
        try (OutputStream output = resolver.openOutputStream(uri);
             OutputStreamWriter writer = new OutputStreamWriter(output)) {

            for (String item : data) {
                // CSV转义
                writer.write("\"" + item.replace("\"", "\"\"") + "\"\n");
            }
            writer.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}