package com.yasee.yaseejava;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.yasee.yasee.Notify;
import com.yasee.yasee.core.enums.CmdType;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yasee.platforms.ky.PlatformKy;
import com.yasee.yaseejava.databinding.ActivityKyBinding;


public class ActivityKy extends AppCompatActivity {

    private ActivityKyBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityKyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Notify.getSingle().listen(_ni);

        binding.button.setOnClickListener((view) -> {
            PlatformKy.single().scanTest();
        });
        binding.clearText.setOnClickListener((view) -> {
            binding.kyReslt.setText("");
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Notify.getSingle().remove(_ni);
    }

    NotifyInterface _ni = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceData;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleNotifyData ssss = (NotifyResp.BleNotifyData) data.data;
            if(ssss.step != CmdType.result) return;

            String _s = ssss.dataToJson();
            String text = String.format("start============\n  指令类型:%s \n  指令可视化数据:%s\nend================\n", ssss.step.name(), _s==null ? "" : _s);

            binding.kyReslt.setText(text);

        }
    };


}