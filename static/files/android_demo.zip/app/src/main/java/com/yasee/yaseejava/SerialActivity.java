package com.yasee.yaseejava;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.yasee.yasee.Notify;
import com.yasee.yasee.Yasee;
import com.yasee.yasee.core.abstracts.AbstractsSerialActivity;
import com.yasee.yasee.core.configs.SerialConfig;
import com.yasee.yasee.core.enums.CmdType;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yasee.core.models.Check;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yasee.core.tools.Logs;
import com.yasee.yasee.protocols.serial.SerialTool;
import com.yasee.yaseejava.databinding.ActivitySerialBinding;

import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public class SerialActivity extends AbstractsSerialActivity {

    private ActivitySerialBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySerialBinding.inflate(getLayoutInflater());
        EdgeToEdge.enable(this);
        setContentView(binding.getRoot());
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });


        Yasee.getSingle().setSerialConfig(true, new SerialConfig());
        Notify.getSingle().listen(_ni);


        binding.clearText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                binding.serialDataShow.setText("");
            }
        });


        binding.serialStartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                send81();
            }
        });

        binding.serialStopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Notify.getSingle().remove(_ni);
    }

    void send83() {
        SerialTool.getSingle().send(new byte[]{
                (byte) 0xAA,
                (byte) 0x55,
                (byte) 0x04,
                (byte) 0x83,
                (byte) 0x01,
                (byte) 0x00,
                (byte) 0x84,
        });
    }
    void send81() {
        SerialTool.getSingle().send(new byte[]{
           (byte) 0xAA, (byte) 0x55, (byte) 0x04, (byte) 0x81,
           (byte) 0xFF, (byte) 0x01, (byte) 0x80,
        });
    }

    NotifyInterface _ni = new NotifyInterface() {
        @Override
        public NotifyType getType() {
            return NotifyType.deviceData;
        }

        @Override
        public void message(NotifyResp data) {
            NotifyResp.BleNotifyData ssss = (NotifyResp.BleNotifyData) data.data;

            // join [-86, 85, 8, -125, 1, 1, 1, 0, 16, 0, -106]
            if (ssss.step == CmdType.join)
                send83();
            else if (ssss.step == CmdType.wakeup || ssss.step == CmdType.serial_join)
                CompletableFuture.runAsync(() -> {
                    try {
                        TimeUnit.MILLISECONDS.sleep(100); // 模拟延时
                        System.out.println("延时后执行任务");
                        send81();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                });



            String _sss = "本次"; //binding.sendData.getText().toString();
            HashMap _s = (HashMap) ssss.data;
            String text = String.format("%s\n start============\n  原始: %s\n  指令类型:%s \n  指令可视化数据:%s\nend================\n", binding.serialDataShow.getText(), Arrays.toString(ssss.raw),ssss.step.name(), _s==null ? "" : _s.toString());
            Logs.print(text);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    binding.serialDataShow.setText(text);
                }
            });
        }
    };
}