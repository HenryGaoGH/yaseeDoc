package com.yasee.yaseejava.adapters;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.Visibility;

import com.yasee.yasee.Notify;
import com.yasee.yasee.protocols.ble.Ble;
import com.yasee.yasee.protocols.ble.BleDevice;
import com.yasee.yasee.core.enums.DeviceProcess;
import com.yasee.yasee.core.enums.NotifyType;
import com.yasee.yasee.core.interfaces.NotifyInterface;
import com.yasee.yasee.core.models.NotifyResp;
import com.yasee.yaseejava.R;

import java.util.List;

import com.yasee.yaseejava.ScanFragment;
import com.yasee.yaseejava.databinding.BleItemBinding;

public class BleItemsAda extends RecyclerView.Adapter<BleItemsAda.BleItemsAdaViewHolder> {
    private List<BleDevice> itemList;
    private BleItemBinding bib;
    private ItemClickListener connectListener;
    private ItemClickListener comeinListener;

    public BleItemsAda(List<BleDevice> itemList,ItemClickListener itemClickListener,ItemClickListener comeinListener) {
        this.itemList = itemList;
        this.connectListener = itemClickListener;
        this.comeinListener = comeinListener;
    }
    public void setItems(List<BleDevice> devices) {
        this.itemList = devices;
        notifyDataSetChanged();
    }
    public interface ItemClickListener {
        void onItemClick(BleDevice item);
    }

    @NonNull
    @Override
    public BleItemsAdaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        bib = BleItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new BleItemsAdaViewHolder(bib.listItem);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onBindViewHolder(@NonNull BleItemsAdaViewHolder holder, int position) {
        BleDevice item = itemList.get(position);
        holder.textView.setText(item.getModel()+(item.getState() == 0 ? "" : "(已连接)"));
        holder.linked.setText(item.getState() == 0 ? "绑定连接" : "解绑");
//        holder.linked.setBackgroundColor(item.getState() == 0 ? "绑定连接" : "解绑");
        holder.linked.setTag(item);
        holder.linked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (connectListener != null) {
                    connectListener.onItemClick((BleDevice) v.getTag());
                }
            }
        });
//        holder.ble_come_in.setVisibility(item.state == 2 ? View.VISIBLE : View.GONE);
        holder.ble_come_in.setTag(item);
        holder.ble_come_in.setOnClickListener(v->{
            if (comeinListener != null) {
                comeinListener.onItemClick((BleDevice) v.getTag());
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    static class BleItemsAdaViewHolder extends RecyclerView.ViewHolder {

        TextView textView;
        Button linked;
        Button ble_come_in;
        private BleItemBinding bib;

        public BleItemsAdaViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textView);
            linked = itemView.findViewById(R.id.ble_linked);
            ble_come_in = itemView.findViewById(R.id.ble_come_in);
        }
    }

}
